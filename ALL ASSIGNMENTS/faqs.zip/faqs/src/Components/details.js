export let faqs = [
  {
    id: 1,
    question: "This is some dummy text just for testing purpose ",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi corrupti cum rerum, beatae doloribus architecto commodi incidunt delectus fuga porro ipsam quibusdam, quaerat doloremque iure tempora fugiat minus? Veniam, aut!",
  },
  {
    id: 2,
    question: "This is some dummy text just for testing purpose ",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi corrupti cum rerum, beatae doloribus architecto commodi incidunt delectus fuga porro ipsam quibusdam, quaerat doloremque iure tempora fugiat minus? Veniam, aut!",
  },
  {
    id: 3,
    question: "This is some dummy text just for testing purpose ",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi corrupti cum rerum, beatae doloribus architecto commodi incidunt delectus fuga porro ipsam quibusdam, quaerat doloremque iure tempora fugiat minus? Veniam, aut!",
  },
  {
    id: 4,
    question: "This is some dummy text just for testing purpose ",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi corrupti cum rerum, beatae doloribus architecto commodi incidunt delectus fuga porro ipsam quibusdam, quaerat doloremque iure tempora fugiat minus? Veniam, aut!",
  },
  {
    id: 5,
    question: "This is some dummy text just for testing purpose ",
    answer:
      "Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi corrupti cum rerum, beatae doloribus architecto commodi incidunt delectus fuga porro ipsam quibusdam, quaerat doloremque iure tempora fugiat minus? Veniam, aut!",
  },
];