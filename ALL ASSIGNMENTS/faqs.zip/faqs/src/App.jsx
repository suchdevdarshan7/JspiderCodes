import React, { useState } from 'react'
import './style.css'
import FaqsPart from './Components/FaqsPart';


function App() {
  return(
    <FaqsPart/>
  )
}
export default App
